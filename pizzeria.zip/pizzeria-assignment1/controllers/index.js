module.exports = {
  auth: require("./auth"),
  user: require("./user"),
  order: require("./order"),
};
